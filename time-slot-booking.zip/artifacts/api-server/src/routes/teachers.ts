import { Router } from "express";
import { db, teachersTable, timeSlotsTable, bookingsTable } from "@workspace/db";
import { eq, isNull, inArray, isNotNull } from "drizzle-orm";
import { requireTeacherSession } from "./auth";

const router = Router();

router.get("/teachers", async (_req, res) => {
  const teachers = await db
    .select({ id: teachersTable.id, name: teachersTable.name, slug: teachersTable.slug, subject: teachersTable.subject })
    .from(teachersTable)
    .orderBy(teachersTable.name);
  res.json(teachers);
});

router.get("/teachers/:slug/timeslots", async (req, res) => {
  const { slug } = req.params;
  const rows = await db.select().from(teachersTable).where(eq(teachersTable.slug, slug)).limit(1);
  if (!rows.length) {
    res.status(404).json({ message: "Teacher not found." });
    return;
  }
  const teacher = rows[0];
  const slots = await db.select().from(timeSlotsTable).where(eq(timeSlotsTable.teacherId, teacher.id));

  // Fetch all bookings for this teacher's slots
  const slotIds = slots.map(s => s.id);
  const allBookings = slotIds.length
    ? await db
        .select({ name: bookingsTable.name, assignedTime: bookingsTable.assignedTime, timeSlotId: bookingsTable.timeSlotId, wasScheduled: bookingsTable.wasScheduled })
        .from(bookingsTable)
        .where(inArray(bookingsTable.timeSlotId, slotIds))
    : [];
  const assignedBookings = allBookings.filter(r => r.assignedTime !== null);
  const unassignedAll = allBookings.filter(r => r.assignedTime === null);
  const unassignedStudents = unassignedAll.filter(r => !r.wasScheduled).map(r => ({ name: r.name }));
  const unschedulableStudents = unassignedAll.filter(r => r.wasScheduled).map(r => ({ name: r.name }));

  // Map slotId -> [{ start, end, name }]
  // Use the slotId encoded in assignedTime ("slotId|HH:MM-HH:MM") — not timeSlotId —
  // because the auto-scheduler can assign a student to a different slot than the one
  // they originally booked into.
  const namesBySlot = new Map<number, { start: string; end: string; name: string }[]>();
  for (const b of assignedBookings) {
    if (!b.assignedTime) continue;
    const pipeIdx = b.assignedTime.indexOf("|");
    const assignedSlotId = pipeIdx !== -1 ? parseInt(b.assignedTime.slice(0, pipeIdx), 10) : b.timeSlotId;
    if (!assignedSlotId || isNaN(assignedSlotId as number)) continue;
    const range = pipeIdx !== -1 ? b.assignedTime.slice(pipeIdx + 1) : b.assignedTime;
    const dashIdx = range.indexOf("-");
    if (dashIdx === -1) continue;
    const start = range.slice(0, dashIdx);
    const end = range.slice(dashIdx + 1);
    const arr = namesBySlot.get(assignedSlotId) ?? [];
    arr.push({ start, end, name: b.name });
    namesBySlot.set(assignedSlotId, arr);
  }

  res.json({
    teacher: {
      id: teacher.id,
      name: teacher.name,
      slug: teacher.slug,
      subject: teacher.subject,
      hideFullyBlocked: teacher.hideFullyBlocked,
      blockFromAppointments: teacher.blockFromAppointments,
      durationOptions: teacher.durationOptions ?? null,
      totalPages: teacher.totalPages ?? 10,
    },
    slots: slots.map(s => ({
      ...s,
      blockedTimes: teacher.blockFromAppointments ? (s.blockedTimes ?? []) : [],
      bookedSessions: namesBySlot.get(s.id) ?? [],
    })),
    unassignedStudents,
    unschedulableStudents,
  });
});

router.post("/teachers", async (req, res) => {
  const { name, slug, passcode, subject, email } = req.body ?? {};
  if (!name?.trim() || !slug?.trim() || !passcode?.trim()) {
    res.status(400).json({ message: "name, slug, and passcode are required." });
    return;
  }
  if (!/^[a-zA-Z0-9-]+$/.test(slug)) {
    res.status(400).json({ message: "Username can only contain letters, numbers, and hyphens." });
    return;
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    res.status(400).json({ message: "Please enter a valid email address." });
    return;
  }
  const existing = await db.select({ id: teachersTable.id }).from(teachersTable).where(eq(teachersTable.slug, slug)).limit(1);
  if (existing.length) {
    res.status(409).json({ message: "That username is already taken. Please choose a different one." });
    return;
  }
  const [teacher] = await db
    .insert(teachersTable)
    .values({ name: name.trim(), slug: slug.trim(), passcode: passcode.trim(), subject: subject?.trim() || null, email: email?.trim() || null })
    .returning();

  await db.update(timeSlotsTable).set({ teacherId: teacher.id }).where(isNull(timeSlotsTable.teacherId));

  res.status(201).json({ id: teacher.id, name: teacher.name, slug: teacher.slug, subject: teacher.subject });
});

router.get("/teachers/me/settings", requireTeacherSession, async (req, res) => {
  const [teacher] = await db
    .select({
      hideFullyBlocked: teachersTable.hideFullyBlocked,
      blockFromAppointments: teachersTable.blockFromAppointments,
      durationOptions: teachersTable.durationOptions,
      totalPages: teachersTable.totalPages,
      minStudentsPerSlot: teachersTable.minStudentsPerSlot,
      maxStudentsPerSlot: teachersTable.maxStudentsPerSlot,
    })
    .from(teachersTable)
    .where(eq(teachersTable.id, res.locals.teacherId))
    .limit(1);
  const totalPages = teacher?.totalPages ?? 10;
  const numChoices = Math.round((totalPages - 1) / 3);
  res.json({
    hideFullyBlocked: teacher?.hideFullyBlocked ?? true,
    blockFromAppointments: teacher?.blockFromAppointments ?? true,
    durationOptions: teacher?.durationOptions ?? null,
    totalPages,
    numChoices,
    minStudentsPerSlot: teacher?.minStudentsPerSlot ?? 1,
    maxStudentsPerSlot: teacher?.maxStudentsPerSlot ?? 1,
  });
});

function isValidDurationOption(item: unknown): item is { label: string; value: number } {
  if (!item || typeof item !== "object") return false;
  const o = item as Record<string, unknown>;
  return (
    typeof o.label === "string" && o.label.trim().length > 0 &&
    typeof o.value === "number" && Number.isInteger(o.value) && o.value >= 1 && o.value <= 480
  );
}

router.patch("/teachers/me/settings", requireTeacherSession, async (req, res) => {
  const { hideFullyBlocked, blockFromAppointments, durationOptions, numChoices, minStudentsPerSlot, maxStudentsPerSlot } = req.body ?? {};
  const updates: Record<string, unknown> = {};
  if (typeof hideFullyBlocked === "boolean") updates.hideFullyBlocked = hideFullyBlocked;
  if (typeof blockFromAppointments === "boolean") updates.blockFromAppointments = blockFromAppointments;
  if (durationOptions === null) {
    updates.durationOptions = null;
  } else if (Array.isArray(durationOptions)) {
    if (!durationOptions.every(isValidDurationOption)) {
      res.status(400).json({ message: "Each duration option must have a non-empty label and an integer value between 1 and 480." });
      return;
    }
    updates.durationOptions = durationOptions;
  }
  if (typeof numChoices === "number" && Number.isInteger(numChoices) && numChoices >= 1 && numChoices <= 5) {
    updates.totalPages = numChoices * 3 + 1;
  }
  if (typeof minStudentsPerSlot === "number" && Number.isInteger(minStudentsPerSlot) && minStudentsPerSlot >= 1) {
    updates.minStudentsPerSlot = minStudentsPerSlot;
  }
  if (typeof maxStudentsPerSlot === "number" && Number.isInteger(maxStudentsPerSlot) && maxStudentsPerSlot >= 1) {
    updates.maxStudentsPerSlot = maxStudentsPerSlot;
  }
  if (Object.keys(updates).length === 0) {
    res.status(400).json({ message: "No valid settings provided" });
    return;
  }
  await db.update(teachersTable).set(updates).where(eq(teachersTable.id, res.locals.teacherId));
  res.json({ ok: true });
});

router.delete("/teachers/me", requireTeacherSession, async (req, res) => {
  const teacherId = res.locals.teacherId as number;
  const slots = await db
    .select({ id: timeSlotsTable.id })
    .from(timeSlotsTable)
    .where(eq(timeSlotsTable.teacherId, teacherId));
  if (slots.length) {
    const slotIds = slots.map((s) => s.id);
    await db.delete(bookingsTable).where(inArray(bookingsTable.timeSlotId, slotIds));
    await db.delete(timeSlotsTable).where(inArray(timeSlotsTable.id, slotIds));
  }
  await db.delete(teachersTable).where(eq(teachersTable.id, teacherId));
  res.clearCookie("teacher_session", { path: "/" });
  res.json({ ok: true });
});

export default router;
